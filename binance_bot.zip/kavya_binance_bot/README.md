# Binance USDT-M Futures Testnet Bot (CLI)

A clean, testnet-only trading bot for Binance **USDT-M Futures** built with Python and plain REST calls.

- **Core**: Market & Limit orders
- **Bonus**: Stop–Limit + TWAP strategy
- **Logging**: Structured logs to `bot.log`
- **Input Validation**: Symbol, side, and numeric fields
- **Testnet Base URL**: `https://testnet.binancefuture.com` (as required in the assignment)

---

## 1) Setup

### Prerequisites
- Python 3.9+
- A **Binance Futures Testnet** account with API key & secret (UM / USDT-M)
- Enable Futures in Testnet and allow futures trading for the key

### Install
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### Configure Environment
Create a `.env` file (or set env vars however you prefer):

```
BINANCE_API_KEY=your_key_here
BINANCE_API_SECRET=your_secret_here
# Optional overrides:
# BINANCE_FUTURES_BASE_URL=https://testnet.binancefuture.com
# BINANCE_RECV_WINDOW=5000
# BINANCE_HTTP_TIMEOUT=30
```

> The app reads `BINANCE_API_KEY` and `BINANCE_API_SECRET` from your environment. You can also export them in your shell.

Load env vars on Linux/macOS:
```bash
export $(cat .env | xargs)
```

On Windows PowerShell:
```powershell
$env:BINANCE_API_KEY="your_key_here"
$env:BINANCE_API_SECRET="your_secret_here"
```

---

## 2) Usage (CLI)

From project root:

```bash
python -m src.cli price BTCUSDT
python -m src.cli market BTCUSDT BUY 0.001
python -m src.cli limit BTCUSDT BUY 0.001 50000 --tif GTC
python -m src.cli stop-limit BTCUSDT SELL 0.001 52000 51950
python -m src.cli twap BTCUSDT BUY 0.01 5 2
```

- `market` places a **MARKET** order.
- `limit` places a **LIMIT** order with **timeInForce**.
- `stop-limit` places a **STOP** order with `stopPrice` and `price` (limit) – on trigger, a LIMIT order is submitted.
- `twap` splits a total size into `slices`, sending MARKET orders every `interval_sec` seconds.

**Both** BUY and SELL are supported; use `--reduce-only` and `--position-side` if you need it.

---

## 3) Project Structure

```
[project_root]/
├── src/
│   ├── binance_client.py      # REST client (signing, requests, common calls)
│   ├── config.py              # Env/config loader
│   ├── logger_setup.py        # Rotating file logger
│   ├── utils.py               # Input validation
│   ├── orders/
│   │   ├── market_orders.py   # MARKET orders
│   │   ├── limit_orders.py    # LIMIT orders
│   │   └── stop_limit.py      # STOP-LIMIT orders (bonus)
│   └── strategies/
│       └── twap.py            # TWAP strategy (bonus)
├── bot.log                    # Logs (created at runtime)
├── requirements.txt
├── README.md
└── report.md
```

---

## 4) Logging

- All requests, responses, and errors are written to `bot.log` (rotating, 1 MB per file, 5 backups).
- Sensitive secrets are **never** logged.

---

## 5) Notes & Gotchas

- This project intentionally uses **raw REST** instead of `python-binance` to keep signing and endpoints explicit and transparent for reviewers.
- Test with tiny quantities (e.g., `0.001`) and valid Symbols available on the **Futures Testnet**.
- OCO is not available on USDT-M Futures; for advanced orders, we implemented **Stop–Limit** and a simple **TWAP**.
- Hedge mode toggles and leverage settings are out of scope; you can add them easily via `/fapi/v1/leverage` and `/fapi/v1/positionSide/dual` if desired.

---

## 6) Requirements

- Python 3.9+
- `requests`, `python-dotenv` (optional for local env loading)

---

## 7) Example Logs

A successful order will produce entries similar to:

```
2025-09-08 21:45:10 | INFO | BinanceFuturesREST | REQUEST POST /fapi/v1/order params={'symbol': 'BTCUSDT', ...}
2025-09-08 21:45:11 | INFO | BinanceFuturesREST | RESPONSE status=200 body={...}
```

---

## 8) License

MIT
