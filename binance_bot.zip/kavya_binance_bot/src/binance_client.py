import time
import hmac
import hashlib
import requests
from typing import Dict, Any
from urllib.parse import urlencode

from .config import load_settings
from .logger_setup import get_logger

class BinanceFuturesREST:
    """Lightweight REST client for Binance USDT-M Futures Testnet (UM /fapi).    Uses HMAC SHA256 signing with query-string signatures."""
    def __init__(self):
        self.settings = load_settings()
        self.session = requests.Session()
        self.session.headers.update({
            "X-MBX-APIKEY": self.settings.api_key
        })
        self.log = get_logger("BinanceFuturesREST")

    # --- Helpers ---
    def _sign(self, params: Dict[str, Any]) -> str:
        query = urlencode(params, doseq=True)
        signature = hmac.new(self.settings.api_secret.encode("utf-8"), query.encode("utf-8"), hashlib.sha256).hexdigest()
        return signature

    def _request(self, method: str, path: str, params: Dict[str, Any] = None, signed: bool = False) -> Dict[str, Any]:
        if params is None:
            params = {}
        url = f"{self.settings.base_url}{path}"
        if signed:
            params.update({
                "recvWindow": self.settings.recv_window,
                "timestamp": int(time.time() * 1000)
            })
            params["signature"] = self._sign(params)

        self.log.info(f"REQUEST {method} {path} params={params}")
        try:
            if method == "GET":
                resp = self.session.get(url, params=params, timeout=self.settings.timeout)
            elif method == "POST":
                resp = self.session.post(url, params=params, timeout=self.settings.timeout)
            elif method == "DELETE":
                resp = self.session.delete(url, params=params, timeout=self.settings.timeout)
            else:
                raise ValueError(f"Unsupported method: {method}")

            self.log.info(f"RESPONSE status={resp.status_code} body={resp.text[:500]}")
            resp.raise_for_status()
            return resp.json()
        except requests.HTTPError as e:
            self.log.error(f"HTTPError: {e} | body={getattr(e.response, 'text', '')}")
            raise
        except Exception as e:
            self.log.exception(f"Error during request: {e}")
            raise

    # --- Public API ---
    def get_server_time(self) -> Dict[str, Any]:
        return self._request("GET", "/fapi/v1/time")

    def get_price(self, symbol: str) -> Dict[str, Any]:
        return self._request("GET", "/fapi/v1/ticker/price", {"symbol": symbol})

    def place_order(self, **kwargs) -> Dict[str, Any]:
        """Place an order on UM Futures. kwargs must include standard params like:
        symbol, side, type, quantity, price?, timeInForce? stopPrice? reduceOnly? positionSide?"""
        return self._request("POST", "/fapi/v1/order", kwargs, signed=True)

    def query_order(self, symbol: str, orderId: int = None, origClientOrderId: str = None) -> Dict[str, Any]:
        params = {"symbol": symbol}
        if orderId is not None:
            params["orderId"] = orderId
        if origClientOrderId is not None:
            params["origClientOrderId"] = origClientOrderId
        return self._request("GET", "/fapi/v1/order", params, signed=True)

    def cancel_order(self, symbol: str, orderId: int = None, origClientOrderId: str = None) -> Dict[str, Any]:
        params = {"symbol": symbol}
        if orderId is not None:
            params["orderId"] = orderId
        if origClientOrderId is not None:
            params["origClientOrderId"] = origClientOrderId
        return self._request("DELETE", "/fapi/v1/order", params, signed=True)
