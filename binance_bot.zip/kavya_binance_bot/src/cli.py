import argparse
import json
from .logger_setup import get_logger
from .orders.market_orders import place_market_order
from .orders.limit_orders import place_limit_order
from .orders.stop_limit import place_stop_limit
from .strategies.twap import run_twap
from .binance_client import BinanceFuturesREST

log = get_logger("CLI")

def main():
    parser = argparse.ArgumentParser(description="Binance USDT-M Futures Testnet Bot (Market/Limit + Bonus)")
    sub = parser.add_subparsers(dest="command", required=True)

    # Market
    p_market = sub.add_parser("market", help="Place a MARKET order")
    p_market.add_argument("symbol", help="e.g., BTCUSDT")
    p_market.add_argument("side", choices=["BUY", "SELL"], help="BUY or SELL")
    p_market.add_argument("quantity", type=float, help="Order quantity")
    p_market.add_argument("--reduce-only", action="store_true", help="Reduce-only order")
    p_market.add_argument("--position-side", choices=["BOTH", "LONG", "SHORT"], help="Hedge mode position side")

    # Limit
    p_limit = sub.add_parser("limit", help="Place a LIMIT order")
    p_limit.add_argument("symbol", help="e.g., BTCUSDT")
    p_limit.add_argument("side", choices=["BUY", "SELL"], help="BUY or SELL")
    p_limit.add_argument("quantity", type=float, help="Order quantity")
    p_limit.add_argument("price", type=float, help="Limit price")
    p_limit.add_argument("--tif", default="GTC", choices=["GTC", "IOC", "FOK", "GTX"], help="Time in Force")
    p_limit.add_argument("--reduce-only", action="store_true", help="Reduce-only order")
    p_limit.add_argument("--position-side", choices=["BOTH", "LONG", "SHORT"], help="Hedge mode position side")

    # Stop-Limit (Bonus)
    p_stop = sub.add_parser("stop-limit", help="Place a STOP-LIMIT order (triggered LIMIT)")
    p_stop.add_argument("symbol", help="e.g., BTCUSDT")
    p_stop.add_argument("side", choices=["BUY", "SELL"], help="BUY or SELL")
    p_stop.add_argument("quantity", type=float, help="Order quantity")
    p_stop.add_argument("stop_price", type=float, help="Stop trigger price")
    p_stop.add_argument("limit_price", type=float, help="Limit price after trigger")
    p_stop.add_argument("--tif", default="GTC", choices=["GTC", "IOC", "FOK", "GTX"], help="Time in Force")
    p_stop.add_argument("--reduce-only", action="store_true", help="Reduce-only order")
    p_stop.add_argument("--position-side", choices=["BOTH", "LONG", "SHORT"], help="Hedge mode position side")

    # TWAP (Bonus)
    p_twap = sub.add_parser("twap", help="Run a simple TWAP strategy (splits into MARKET slices)")
    p_twap.add_argument("symbol", help="e.g., BTCUSDT")
    p_twap.add_argument("side", choices=["BUY", "SELL"], help="BUY or SELL")
    p_twap.add_argument("total_qty", type=float, help="Total quantity to trade")
    p_twap.add_argument("slices", type=int, help="Number of slices")
    p_twap.add_argument("interval_sec", type=float, help="Seconds to wait between slices")

    # Utility
    p_price = sub.add_parser("price", help="Get current mark price for a symbol")
    p_price.add_argument("symbol", help="e.g., BTCUSDT")

    args = parser.parse_args()
    try:
        if args.command == "market":
            res = place_market_order(args.symbol, args.side, args.quantity, reduce_only=args.reduce_only, position_side=args.position_side)
        elif args.command == "limit":
            res = place_limit_order(args.symbol, args.side, args.quantity, args.price, tif=args.tif, reduce_only=args.reduce_only, position_side=args.position_side)
        elif args.command == "stop-limit":
            res = place_stop_limit(args.symbol, args.side, args.quantity, args.stop_price, args.limit_price, tif=args.tif, reduce_only=args.reduce_only, position_side=args.position_side)
        elif args.command == "twap":
            res = run_twap(args.symbol, args.side, args.total_qty, args.slices, args.interval_sec)
        elif args.command == "price":
            client = BinanceFuturesREST()
            res = client.get_price(args.symbol)
        else:
            raise ValueError("Unknown command")
        print(json.dumps(res, indent=2))
    except Exception as e:
        log.exception(f"Command failed: {e}")
        raise

if __name__ == "__main__":
    main()
