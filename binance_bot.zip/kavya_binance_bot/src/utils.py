def validate_symbol(symbol: str) -> str:
    if not symbol or not symbol.isalnum() or not symbol.endswith("USDT"):
        raise ValueError("Symbol must be alphanumeric and end with 'USDT' (e.g., BTCUSDT).")
    return symbol.upper()

def validate_side(side: str) -> str:
    side = side.upper()
    if side not in {"BUY", "SELL"}:
        raise ValueError("Side must be BUY or SELL.")
    return side

def validate_positive_float(name: str, value: float) -> float:
    try:
        v = float(value)
    except Exception:
        raise ValueError(f"{name} must be a number.")
    if v <= 0:
        raise ValueError(f"{name} must be > 0.")
    return v
