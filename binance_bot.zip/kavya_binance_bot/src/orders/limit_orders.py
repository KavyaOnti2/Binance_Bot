from typing import Dict, Any
from ..binance_client import BinanceFuturesREST
from ..utils import validate_symbol, validate_side, validate_positive_float
from ..logger_setup import get_logger

log = get_logger("LimitOrder")

def place_limit_order(symbol: str, side: str, quantity: float, price: float, tif: str = "GTC", reduce_only: bool = False, position_side: str = None) -> Dict[str, Any]:
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    quantity = validate_positive_float("quantity", quantity)
    price = validate_positive_float("price", price)

    params = {
        "symbol": symbol,
        "side": side,
        "type": "LIMIT",
        "timeInForce": tif,
        "quantity": quantity,
        "price": price,
    }
    if reduce_only:
        params["reduceOnly"] = "true"
    if position_side:
        params["positionSide"] = position_side

    client = BinanceFuturesREST()
    log.info(f"Placing LIMIT order: {params}")
    return client.place_order(**params)
