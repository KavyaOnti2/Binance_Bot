from typing import Dict, Any
from ..binance_client import BinanceFuturesREST
from ..utils import validate_symbol, validate_side, validate_positive_float
from ..logger_setup import get_logger

log = get_logger("StopLimitOrder")

def place_stop_limit(symbol: str, side: str, quantity: float, stop_price: float, limit_price: float, tif: str = "GTC", reduce_only: bool = False, position_side: str = None) -> Dict[str, Any]:
    """Futures stop-limit is expressed as type=STOP with stopPrice + price (limit).

    On trigger, a LIMIT order at `price` is placed.

    See: type=STOP (not STOP_MARKET) for /fapi/v1/order"""
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    quantity = validate_positive_float("quantity", quantity)
    stop_price = validate_positive_float("stop_price", stop_price)
    limit_price = validate_positive_float("limit_price", limit_price)

    params = {
        "symbol": symbol,
        "side": side,
        "type": "STOP",
        "timeInForce": tif,
        "quantity": quantity,
        "stopPrice": stop_price,
        "price": limit_price,
        "workingType": "MARK_PRICE",  # or CONTRACT_PRICE
    }
    if reduce_only:
        params["reduceOnly"] = "true"
    if position_side:
        params["positionSide"] = position_side

    client = BinanceFuturesREST()
    log.info(f"Placing STOP-LIMIT order: {params}")
    return client.place_order(**params)
