from typing import Dict, Any
from ..binance_client import BinanceFuturesREST
from ..utils import validate_symbol, validate_side, validate_positive_float
from ..logger_setup import get_logger

log = get_logger("MarketOrder")

def place_market_order(symbol: str, side: str, quantity: float, reduce_only: bool = False, position_side: str = None) -> Dict[str, Any]:
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    quantity = validate_positive_float("quantity", quantity)

    params = {
        "symbol": symbol,
        "side": side,
        "type": "MARKET",
        "quantity": quantity,
    }
    if reduce_only:
        params["reduceOnly"] = "true"
    if position_side:
        params["positionSide"] = position_side  # BOTH / LONG / SHORT

    client = BinanceFuturesREST()
    log.info(f"Placing MARKET order: {params}")
    return client.place_order(**params)
