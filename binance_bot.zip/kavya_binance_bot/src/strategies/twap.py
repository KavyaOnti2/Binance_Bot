import time
from typing import Dict, Any
from ..logger_setup import get_logger
from ..utils import validate_symbol, validate_side, validate_positive_float
from ..orders.market_orders import place_market_order

log = get_logger("TWAP")

def run_twap(symbol: str, side: str, total_qty: float, slices: int, interval_sec: float) -> Dict[str, Any]:
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    total_qty = validate_positive_float("total_qty", total_qty)
    slices = int(validate_positive_float("slices", slices))
    interval_sec = validate_positive_float("interval_sec", interval_sec)

    qty_per = round(total_qty / slices, 8)
    results = []
    log.info(f"Starting TWAP: symbol={symbol} side={side} total={total_qty} slices={slices} interval={interval_sec}")
    for i in range(slices):
        res = place_market_order(symbol, side, qty_per)
        results.append(res)
        log.info(f"TWAP slice {i+1}/{slices} placed: {res}")
        if i < slices - 1:
            time.sleep(interval_sec)
    return {"status": "completed", "slices": slices, "qty_per_slice": qty_per, "orders": results}
