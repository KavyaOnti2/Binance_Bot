import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    api_key: str
    api_secret: str
    base_url: str = "https://testnet.binancefuture.com"  # Futures Testnet per assignment
    recv_window: int = 5000
    timeout: int = 30  # seconds

def load_settings():
    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")
    if not api_key or not api_secret:
        raise RuntimeError("Missing BINANCE_API_KEY or BINANCE_API_SECRET environment variables.")
    base_url = os.getenv("BINANCE_FUTURES_BASE_URL", "https://testnet.binancefuture.com")
    recv_window = int(os.getenv("BINANCE_RECV_WINDOW", "5000"))
    timeout = int(os.getenv("BINANCE_HTTP_TIMEOUT", "30"))
    return Settings(api_key=api_key, api_secret=api_secret, base_url=base_url, recv_window=recv_window, timeout=timeout)
