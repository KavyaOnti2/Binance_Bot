# Assignment Report – Binance Futures Order Bot

**Author:** Kavya Lakshmappa  
**Date:** 2025-09-08

## Overview
This bot targets **Binance USDT-M Futures Testnet** and supports:
- Core orders: **Market**, **Limit**
- Bonus: **Stop–Limit**, **TWAP** (time-sliced market execution)

## Design
- **REST-first**: Explicit HMAC signing and URL handling against `https://testnet.binancefuture.com`.
- **Reusable modules**: `binance_client.py` (transport/signing), `orders/` (order types), `strategies/` (TWAP).
- **CLI UX**: Clear subcommands, strict validation, JSON output for easy piping.
- **Logging**: Rotating `bot.log` with request/response/status.

## Testing Summary
- Verified non-signed endpoints: `/fapi/v1/time`, `/fapi/v1/ticker/price`.
- Order placement tested with small sizes on symbols like `BTCUSDT` (requires live testnet keys).

## Next Steps (if extended)
- Leverage & margin config, risk checks
- WebSocket user stream for fills/positions
- Simple TUI with rich progress/status
